#!/usr/bin/env python3
"""
Scan all ADF JSON files for hardcoded secrets.
Fails CI if any are found — all secrets must use Key Vault references.
"""

import json
import re
import sys
from pathlib import Path

BANNED_PATTERNS = [
    (r"AccountKey=[A-Za-z0-9+/=]{20,}", "Storage account key"),
    (r'"password"\s*:\s*"(?!\{)[^"]{3,}"', "Hardcoded password"),
    (r'"connectionString"\s*:\s*"(?!\{)[^"]{10,}"', "Hardcoded connection string"),
    (r"SharedAccessSignature", "Hardcoded SAS token"),
    (r'"accessToken"\s*:\s*"(?!\{)[^"]{10,}"', "Hardcoded access token"),
]

SAFE_PATTERN = r'"type"\s*:\s*"AzureKeyVaultSecret"'


def scan(adf_dir: Path) -> list[tuple[str, str, str]]:
    issues = []
    for f in adf_dir.rglob("*.json"):
        text = f.read_text(encoding="utf-8")
        for pattern, label in BANNED_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for m in matches:
                if not re.search(SAFE_PATTERN, text):
                    issues.append((str(f), label, m[:60]))
    return issues


if __name__ == "__main__":
    adf_dir = Path(__file__).parent.parent / "adf"
    issues = scan(adf_dir)
    if issues:
        print("SECRET SCAN FAILED — hardcoded secrets detected:")
        for path, label, snippet in issues:
            print(f"  ✗ [{label}] {path}: {snippet}...")
        print("\nAll secrets must use Azure Key Vault references.")
        sys.exit(1)
    print("✓ No hardcoded secrets found in ADF JSON files.")
