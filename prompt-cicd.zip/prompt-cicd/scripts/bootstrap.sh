#!/usr/bin/env bash
# Bootstrap script — run once to set up the project environment
set -euo pipefail

echo "=== prompt-cicd bootstrap ==="

# ── Python environment ───────────────────────────────────────────────────────
echo "[1/5] Creating Python virtual environment..."
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo "  ✓ Python deps installed"

# ── Databricks CLI ───────────────────────────────────────────────────────────
echo "[2/5] Installing Databricks CLI..."
if ! command -v databricks &>/dev/null; then
  curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh
fi
databricks --version
echo "  ✓ Databricks CLI ready"

# ── Azure CLI ────────────────────────────────────────────────────────────────
echo "[3/5] Checking Azure CLI..."
if ! command -v az &>/dev/null; then
  echo "  Azure CLI not found. Install from: https://docs.microsoft.com/cli/azure/install-azure-cli"
else
  az --version | head -1
  echo "  ✓ Azure CLI ready"
fi

# ── Copy .env ────────────────────────────────────────────────────────────────
echo "[4/5] Setting up environment file..."
if [ ! -f .env ]; then
  cp .env.example .env
  echo "  ✓ .env created — please fill in your credentials"
else
  echo "  .env already exists — skipping"
fi

# ── Validate setup ───────────────────────────────────────────────────────────
echo "[5/5] Running unit tests (dry run)..."
pytest tests/ -q --tb=short 2>/dev/null || echo "  ⚠ Some tests need env vars — set .env and re-run"

echo ""
echo "=== Bootstrap complete ==="
echo ""
echo "Next steps:"
echo "  1. Fill in .env with your credentials"
echo "  2. Test the agent:"
echo "     python agent/main.py \\"
echo "       --platform databricks \\"
echo "       --file databricks/notebooks/silver/silver_orders.py \\"
echo "       --prompt 'Add row count logging after deduplication' \\"
echo "       --dry-run"
echo ""
echo "  3. Add GitHub Secrets (Settings → Secrets → Actions):"
echo "     ANTHROPIC_API_KEY, GITHUB_TOKEN, DATABRICKS_HOST,"
echo "     DATABRICKS_TOKEN, AZURE_CLIENT_ID, AZURE_TENANT_ID,"
echo "     AZURE_SUBSCRIPTION_ID, AZURE_RESOURCE_GROUP, ADF_FACTORY_NAME"
