#!/usr/bin/env python3
"""
Validate all ADF JSON files have required fields and no hardcoded secrets.
Run in CI before ARM deployment.
"""

import json
import re
import sys
from pathlib import Path

REQUIRED_FIELDS = {
    "pipeline": {"name", "type", "properties"},
    "dataset": {"name", "type", "properties"},
    "linkedService": {"name", "type", "properties"},
}

SECRET_PATTERNS = [
    r"AccountKey=",
    r"Password=",
    r"pwd=",
    r"secret=",
    r"token=",
    r'"password"\s*:\s*"[^{]',
    r'"connectionString"\s*:\s*"[^{]',
]

def validate_adf_files(base_dir: Path) -> list[str]:
    errors = []
    for folder, required in REQUIRED_FIELDS.items():
        for json_file in (base_dir / folder).glob("*.json"):
            try:
                obj = json.loads(json_file.read_text())
            except json.JSONDecodeError as e:
                errors.append(f"INVALID JSON: {json_file} — {e}")
                continue

            missing = required - set(obj.keys())
            if missing:
                errors.append(f"MISSING FIELDS {missing}: {json_file}")

            raw = json_file.read_text()
            for pattern in SECRET_PATTERNS:
                if re.search(pattern, raw, re.IGNORECASE):
                    errors.append(f"POSSIBLE HARDCODED SECRET ({pattern}): {json_file}")
    return errors


if __name__ == "__main__":
    base = Path(__file__).parent.parent / "adf"
    errs = validate_adf_files(base)
    if errs:
        print("ADF validation errors:")
        for e in errs:
            print(f"  ✗ {e}")
        sys.exit(1)
    print(f"✓ All ADF files valid ({sum(1 for _ in base.rglob('*.json'))} files checked)")
