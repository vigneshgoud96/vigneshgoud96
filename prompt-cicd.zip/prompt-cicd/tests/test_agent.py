"""
Unit tests for prompt-cicd agent components.
Uses mocks to avoid real API calls in CI.
"""

import json
import pytest
from unittest.mock import MagicMock, patch, PropertyMock


# ── Parser tests ─────────────────────────────────────────────────────────────

class TestPromptParser:
    def test_heuristic_classify_modify(self):
        from agent.parser import PromptParser
        p = PromptParser.__new__(PromptParser)
        assert p._classify_operation("add deduplication logic") == "modify"
        assert p._classify_operation("update cluster size") == "modify"
        assert p._classify_operation("change the file format") == "modify"

    def test_heuristic_classify_create(self):
        from agent.parser import PromptParser
        p = PromptParser.__new__(PromptParser)
        assert p._classify_operation("create a new gold notebook") == "create"
        assert p._classify_operation("generate a new ADF pipeline") == "create"

    def test_heuristic_classify_delete(self):
        from agent.parser import PromptParser
        p = PromptParser.__new__(PromptParser)
        assert p._classify_operation("delete the old linked service") == "delete"

    @patch("agent.parser.anthropic.Anthropic")
    def test_parse_returns_intent(self, mock_anthropic):
        mock_client = MagicMock()
        mock_anthropic.return_value = mock_client
        mock_client.messages.create.return_value = MagicMock(
            content=[MagicMock(text=json.dumps({
                "operation": "modify",
                "platform": "databricks",
                "file_path": "databricks/notebooks/silver/silver_orders.py",
                "summary": "Add deduplication on order_id",
                "estimated_lines_changed": 3,
                "risk_level": "low",
                "risk_reason": "Additive change only",
            }))]
        )
        from agent.parser import PromptParser
        p = PromptParser(api_key="test-key")
        result = p.parse("databricks", "databricks/notebooks/silver/silver_orders.py", "add dedup")
        assert result["operation"] == "modify"
        assert result["risk_level"] == "low"

    @patch("agent.parser.anthropic.Anthropic")
    def test_parse_falls_back_on_bad_json(self, mock_anthropic):
        mock_client = MagicMock()
        mock_anthropic.return_value = mock_client
        mock_client.messages.create.return_value = MagicMock(
            content=[MagicMock(text="not valid json")]
        )
        from agent.parser import PromptParser
        p = PromptParser(api_key="test-key")
        result = p.parse("adf-pipeline", "adf/pipeline/pl_orders.json", "add retry policy")
        assert "operation" in result
        assert "file_path" in result


# ── Patcher tests ─────────────────────────────────────────────────────────────

class TestFilePatcher:
    def test_strip_fences(self):
        from agent.patcher import FilePatcher
        assert FilePatcher._strip_fences("```python\ncode here\n```") == "code here"
        assert FilePatcher._strip_fences("```\ncode\n```") == "code"
        assert FilePatcher._strip_fences("no fences") == "no fences"

    def test_unified_diff_detects_changes(self):
        from agent.patcher import FilePatcher
        original = "line1\nline2\nline3\n"
        modified = "line1\nline2 changed\nline3\nnew line\n"
        diff = FilePatcher._unified_diff(original, modified, "test.py")
        assert "-line2" in diff
        assert "+line2 changed" in diff
        assert "+new line" in diff

    def test_unified_diff_no_change(self):
        from agent.patcher import FilePatcher
        content = "no changes here\n"
        diff = FilePatcher._unified_diff(content, content, "test.py")
        assert diff == ""


# ── Validator tests ──────────────────────────────────────────────────────────

class TestValidator:
    def setup_method(self):
        from agent.validator import Validator
        self.v = Validator()

    def test_valid_python_notebook(self):
        content = "from pyspark.sql import SparkSession\nspark = SparkSession.builder.getOrCreate()\n"
        with patch.object(self.v, "_run_bundle_validate", return_value={"passed": True, "message": "ok", "error": None}):
            result = self.v._validate_databricks_notebook("test.py", content)
        assert result["passed"] is True

    def test_invalid_python_syntax(self):
        content = "def broken(\n  print('unclosed'\n"
        result = self.v._validate_databricks_notebook("test.py", content)
        assert result["passed"] is False
        assert "syntax" in result["error"].lower()

    def test_valid_adf_json(self):
        content = json.dumps({
            "name": "pl_test",
            "type": "pipelines",
            "properties": {"activities": []}
        })
        with patch.object(self.v, "_arm_validate", return_value={"passed": True, "message": "ok", "error": None}):
            result = self.v._validate_adf_json("pl_test.json", content)
        assert result["passed"] is True

    def test_invalid_adf_json_missing_fields(self):
        content = json.dumps({"name": "pl_test"})
        result = self.v._validate_adf_json("pl_test.json", content)
        assert result["passed"] is False
        assert "missing required fields" in result["error"]

    def test_invalid_adf_json_syntax(self):
        result = self.v._validate_adf_json("pl_test.json", "{not valid json}")
        assert result["passed"] is False
        assert "JSON parse error" in result["error"]

    def test_generic_validator_empty_content(self):
        result = self.v._validate_generic("test.txt", "  ")
        assert result["passed"] is False

    def test_generic_validator_non_empty(self):
        result = self.v._validate_generic("test.txt", "some content")
        assert result["passed"] is True


# ── GitOps tests ─────────────────────────────────────────────────────────────

class TestGitOps:
    @patch("agent.git_ops.Github")
    def test_get_file_returns_content(self, mock_github):
        import base64
        mock_contents = MagicMock()
        mock_contents.content = base64.b64encode(b"notebook content").decode()
        mock_contents.sha = "abc123def456"
        mock_repo = MagicMock()
        mock_repo.get_contents.return_value = mock_contents
        mock_github.return_value.get_repo.return_value = mock_repo

        from agent.git_ops import GitOps
        g = GitOps(token="test", repo_name="org/repo")
        content, sha = g.get_file("path/to/file.py")
        assert content == "notebook content"
        assert sha == "abc123def456"

    @patch("agent.git_ops.Github")
    def test_get_file_returns_empty_on_404(self, mock_github):
        from github import GithubException
        mock_repo = MagicMock()
        mock_repo.get_contents.side_effect = GithubException(404, "Not Found")
        mock_github.return_value.get_repo.return_value = mock_repo

        from agent.git_ops import GitOps
        g = GitOps(token="test", repo_name="org/repo")
        content, sha = g.get_file("nonexistent.py")
        assert content == ""
        assert sha == ""
