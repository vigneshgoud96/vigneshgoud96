"""
Parses natural language prompts into structured intent objects.
Uses Claude to classify operation type, target platform, and affected files.
"""

import json
import logging
import anthropic

log = logging.getLogger(__name__)

PLATFORM_PATHS = {
    "databricks": "databricks/notebooks",
    "databricks-job": "databricks/jobs",
    "adf-pipeline": "adf/pipeline",
    "adf-dataset": "adf/dataset",
    "adf-linked": "adf/linkedService",
}

OPERATION_KEYWORDS = {
    "create": ["create", "add new", "new file", "scaffold", "generate"],
    "modify": ["modify", "update", "change", "add", "remove", "fix", "refactor", "rename", "edit"],
    "delete": ["delete", "remove file", "drop"],
}

SYSTEM_PROMPT = """You are an Azure Data Engineering assistant specialising in Databricks and Azure Data Factory.

Given a user prompt and a target platform, return a JSON object with these fields:
- operation: one of "create", "modify", "delete"
- platform: the platform passed in (echo it back)
- file_path: the exact relative repo path to the target file
- summary: one sentence describing the change
- estimated_lines_changed: integer estimate
- risk_level: one of "low", "medium", "high"
- risk_reason: brief reason for risk level

Respond ONLY with valid JSON. No markdown, no explanation."""


class PromptParser:
    def __init__(self, api_key: str | None = None):
        import os
        self._client = anthropic.Anthropic(api_key=api_key or os.environ["ANTHROPIC_API_KEY"])
        self._model = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-20250514")

    def parse(self, platform: str, file_path: str, prompt: str) -> dict:
        """Return structured intent from a natural language prompt."""
        user_msg = (
            f"Platform: {platform}\n"
            f"File path: {file_path}\n"
            f"Prompt: {prompt}"
        )
        try:
            response = self._client.messages.create(
                model=self._model,
                max_tokens=512,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            )
            raw = response.content[0].text.strip()
            intent = json.loads(raw)
            intent.setdefault("platform", platform)
            intent.setdefault("file_path", file_path)
            intent.setdefault("operation", self._classify_operation(prompt))
            log.info("Parsed intent: %s", intent)
            return intent
        except (json.JSONDecodeError, Exception) as e:
            log.warning("LLM parse failed (%s), falling back to heuristics", e)
            return self._heuristic_parse(platform, file_path, prompt)

    def _classify_operation(self, prompt: str) -> str:
        lower = prompt.lower()
        for op, keywords in OPERATION_KEYWORDS.items():
            if any(k in lower for k in keywords):
                return op
        return "modify"

    def _heuristic_parse(self, platform: str, file_path: str, prompt: str) -> dict:
        return {
            "platform": platform,
            "file_path": file_path,
            "operation": self._classify_operation(prompt),
            "summary": prompt[:120],
            "estimated_lines_changed": 10,
            "risk_level": "medium",
            "risk_reason": "Could not fully parse intent — manual review recommended",
        }
